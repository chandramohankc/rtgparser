//package com.vw.rtgparser.model;
//
//import javax.persistence.*;
//
//@Entity
//@Table(name="extended_location")
//public class ExtendedLocation {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    private long id;
//
//
////    private RTG rtg;
//
//    private String vehicleID;
//
//    private String heading;
//
//    private String latitude;
//
//    private String Longitude ;
//
//
//    public String getVehicleID() {
//        return vehicleID;
//    }
//
//    public void setVehicleID(String vehicleID) {
//        this.vehicleID = vehicleID;
//    }
//
//    public long getId() {
//        return id;
//    }
//
//    public void setId(long id) {
//        this.id = id;
//    }
//
//    public String getHeading() {
//        return heading;
//    }
//
//    public void setHeading(String heading) {
//        this.heading = heading;
//    }
//
//    public String getLatitude() {
//        return latitude;
//    }
//
//    public void setLatitude(String latitude) {
//        this.latitude = latitude;
//    }
//
//    public String getLongitude() {
//        return Longitude;
//    }
//
//    public void setLongitude(String longitude) {
//        Longitude = longitude;
//    }
//}
