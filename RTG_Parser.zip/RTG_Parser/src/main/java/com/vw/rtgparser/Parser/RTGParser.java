package com.vw.rtgparser.Parser;

import com.vw.rtgparser.Repository.RTGRepo;
import com.vw.rtgparser.model.RTG;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RTGParser {


    @Autowired
    RTGRepo repo;


    @Value("${input.path}")
    String inputFilePath;

    private void readFile(String filePath) throws IOException {


        //Read Files and process
        File directoryPath = new File(filePath);
        //List of all files and directories
        File filesList[] = directoryPath.listFiles();
        System.out.println("List of files and directories in the specified directory:");

        Scanner sc = null;
        for (File fil : filesList) {

            System.out.println("Current File: " + fil.getAbsolutePath() + "//" + fil.getName());
            //Only processing text files
            if (null != fil && fil.getName().contains("txt")) {

                BufferedReader reader = new BufferedReader(new FileReader(fil));
                String line = null;
                StringBuilder stringBuilder = new StringBuilder();
                String ls = System.getProperty("line.separator");

                try {
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                        stringBuilder.append(ls);
                    }

                    String fileContentsToParse = stringBuilder.toString();
                    parseAndSaveFileData(fileContentsToParse);
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    reader.close();
                }

            }

        }
    }


    public void parseAndSaveFileData(String st2) throws JSONException {

        st2 = st2.replace("\n", "").replace("\r", "");
        st2 = st2.replaceAll("\\s+", "");
        String str = st2;

        System.out.println(str);

        List<String> li = new ArrayList<String>();
        List<RTG> rtgList = new ArrayList<RTG>();

        int count = 0;

        String regex = "messageCounter\":\\d+}";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(st2);

        List<Integer> allMatches = new ArrayList<Integer>();
        while (matcher.find()) {
            allMatches.add(matcher.end());
        }


        for (int i = 0; i < allMatches.size(); i++) {

            li.add(st2.substring(count, allMatches.get(i)));
            count = allMatches.get(i);

        }

        //Make it a JSON
        String res = "[";

        for (String ss : li) {
            res += ss + ",";
        }

        if (res.endsWith(",")) {
            res = res.substring(0, res.length() - 1);

        }

        res += "]";

        System.out.println("Res: " + res);

        final JSONArray geodata = new JSONArray(res);
        final int n = geodata.length();
        for (int i = 0; i < n; ++i) {

            final JSONObject root = geodata.getJSONObject(i);
            final JSONObject eventHandler = root.getJSONObject("eventHeader");

//            System.out.println(eventHandler.getString("id"));
//            System.out.println(eventHandler.getString("vehichleId"));

            try {

                //dataSweepNotificationData Array
                final JSONArray deviceSweepArray = root.getJSONArray("dataSweepNotificationData");
                if (null != deviceSweepArray) {
                    final int deviceSweepLen = deviceSweepArray.length();

                    for (int j = 0; j < deviceSweepLen; j++) {
                        final JSONObject ds = deviceSweepArray.getJSONObject(j);

                        RTG rtg = new RTG();
                        rtg.setVehicleId(eventHandler.getString("id"));

                        rtg.setIgnitionStatus(String.valueOf(ds.getInt("ignitionStatus")).equalsIgnoreCase("0") ? "OFF" : "ON");
                        rtg.setEventTimestampVehicle(ds.getString("eventTimestampVehicle"));

                        rtg.setLateralAcceleration(ds.getString("lateralAcceleration"));
                        rtg.setLongitudinalAcceleration(ds.getString("longitudinalAcceleration"));

                        rtg.setInstrumentClusterSpeed(ds.getString("instrumentClusterSpeed"));
                        rtg.setOdometer(ds.getString("odometer"));


                        //Extended Location
//                        ExtendedLocation elo = new ExtendedLocation();
                        final JSONObject extendedLocationObject = ds.getJSONObject("extendedLocation");
                        if (null != extendedLocationObject) {

                            final JSONObject locationObject = extendedLocationObject.getJSONObject("location");
                            rtg.setLatitude(locationObject.getString("latitude"));
                            rtg.setLongitude(locationObject.getString("longitude"));
                            rtg.setHeading(extendedLocationObject.getString("heading"));
                        }


                        //Seat Belts
                        final JSONArray seatStatusArray = ds.getJSONArray("seatStatus");
                        if (null != seatStatusArray) {

                            for (int k = 0; k < seatStatusArray.length(); k++) {

                                final JSONObject seatStatusN = seatStatusArray.getJSONObject(k);
                                String seatBeltState = seatStatusN.getString("seatBeltState");
                                String seatBeltStateValue = seatBeltState.equalsIgnoreCase("1") ? "false" : "true";

                                //Not setting true or false state if seat belt state is not in 0 or 1 range,
                                if (!seatBeltState.equalsIgnoreCase("0") && !seatBeltState.equalsIgnoreCase("1")) {
                                    seatBeltStateValue  = seatBeltState;
                                }

                                switch (k) {

                                    case 0:
                                        rtg.setSeatBeltState0(seatBeltStateValue);
                                        break;
                                    case 1:
                                        rtg.setSeatBeltState1(seatBeltStateValue);
                                        break;

                                    case 2:
                                        rtg.setSeatBeltState2(seatBeltStateValue);
                                        break;
                                    case 3:
                                        rtg.setSeatBeltState3(seatBeltStateValue);
                                        break;

                                    case 4:
                                        rtg.setSeatBeltState4(seatBeltStateValue);
                                        break;
                                    case 5:
                                        rtg.setSeatBeltState5(seatBeltStateValue);
                                        break;

                                    case 6:
                                        rtg.setSeatBeltState6(seatBeltStateValue);
                                        break;
                                    case 7:
                                        rtg.setSeatBeltState7(seatBeltStateValue);
                                        break;

                                    default:
                                        break;


                                }

                            }

                        }//Seat Belt Status Array

                        if (null != rtg && null != rtg.getVehicleId()) {
                            rtgList.add(rtg);
                        }

                    } // dataSweepNotificationData For Ends

                } //dataSweepNotificationData If Ends
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }


        }

        repo.saveAll(rtgList);
    }

    public void runAfterObjectCreated() throws IOException {

        try {

            readFile(inputFilePath);

            System.out.println("All files parsed ");
            throw new NullPointerException();

        } catch (Exception e) {

            System.out.println("Exception caught in main method: " + e.getMessage());

        } finally {
            System.out.println("Exiting...");
        }


    }
}
