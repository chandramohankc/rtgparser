//package com.vw.rtgparser.Repository;
//
//import com.vw.rtgparser.model.ExtendedLocation;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ExtendedLocationRepo extends JpaRepository<ExtendedLocation, String>
//{
//
//}