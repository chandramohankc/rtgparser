package com.vw.rtgparser.model;


import org.codehaus.jackson.annotate.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "RTG")
public class RTG {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String vehicleId;

    //    @OneToOne(targetEntity=ExtendedLocation.class, mappedBy="vehicleID",
//            fetch=FetchType.EAGER)
//    @OneToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "vid", referencedColumnName = "vehicleID")
//    ExtendedLocation extendedLocation;

    private String heading;

    private String latitude;

    private String Longitude;

    private String seatBeltState0;

    private String seatBeltState1;

    private String seatBeltState2;

    private String seatBeltState3;

    private String seatBeltState4;

    private String seatBeltState5;

    private String seatBeltState6;

    private String seatBeltState7;

    private String ignitionStatus;

    private String eventTimestampVehicle;

    private String instrumentClusterSpeed;

    private String odometer;

    private String lateralAcceleration;

    private String longitudinalAcceleration;


    public RTG() {

        this.vehicleId = "";

        this.heading = "";
        this.latitude = "";
        this.Longitude = "";

        this.ignitionStatus = "";
        this.odometer = "";

        this.eventTimestampVehicle = "";
        this.instrumentClusterSpeed = "";

        this.lateralAcceleration = "";
        this.longitudinalAcceleration = "";

        this.seatBeltState0 = "";
        this.seatBeltState1 = "";
        this.seatBeltState2 = "";
        this.seatBeltState3 = "";
        this.seatBeltState4 = "";
        this.seatBeltState5 = "";
        this.seatBeltState6 = "";
        this.seatBeltState7 = "";
    }


    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return Longitude;
    }

    public void setLongitude(String longitude) {
        Longitude = longitude;
    }

    public String getSeatBeltState0() {
        return seatBeltState0;
    }

    public void setSeatBeltState0(String seatBeltState0) {
        this.seatBeltState0 = seatBeltState0;
    }

    public String getSeatBeltState1() {
        return seatBeltState1;
    }

    public void setSeatBeltState1(String seatBeltState1) {
        this.seatBeltState1 = seatBeltState1;
    }

    public String getSeatBeltState2() {
        return seatBeltState2;
    }

    public void setSeatBeltState2(String seatBeltState2) {
        this.seatBeltState2 = seatBeltState2;
    }

    public String getSeatBeltState3() {
        return seatBeltState3;
    }

    public void setSeatBeltState3(String seatBeltState3) {
        this.seatBeltState3 = seatBeltState3;
    }

    public String getSeatBeltState4() {
        return seatBeltState4;
    }

    public void setSeatBeltState4(String seatBeltState4) {
        this.seatBeltState4 = seatBeltState4;
    }

    public String getSeatBeltState5() {
        return seatBeltState5;
    }

    public void setSeatBeltState5(String seatBeltState5) {
        this.seatBeltState5 = seatBeltState5;
    }

    public String getSeatBeltState6() {
        return seatBeltState6;
    }

    public void setSeatBeltState6(String seatBeltState6) {
        this.seatBeltState6 = seatBeltState6;
    }

    public String getSeatBeltState7() {
        return seatBeltState7;
    }

    public void setSeatBeltState7(String seatBeltState7) {
        this.seatBeltState7 = seatBeltState7;
    }

    public String getIgnitionStatus() {
        return ignitionStatus;
    }

    public void setIgnitionStatus(String ignitionStatus) {
        this.ignitionStatus = ignitionStatus;
    }

    public String getEventTimestampVehicle() {
        return eventTimestampVehicle;
    }

    public void setEventTimestampVehicle(String eventTimestampVehicle) {
        this.eventTimestampVehicle = eventTimestampVehicle;
    }

    public String getInstrumentClusterSpeed() {
        return instrumentClusterSpeed;
    }

    public void setInstrumentClusterSpeed(String instrumentClusterSpeed) {
        this.instrumentClusterSpeed = instrumentClusterSpeed;
    }

    public String getOdometer() {
        return odometer;
    }

    public void setOdometer(String odometer) {
        this.odometer = odometer;
    }

    public String getLateralAcceleration() {
        return lateralAcceleration;
    }

    public void setLateralAcceleration(String lateralAcceleration) {
        this.lateralAcceleration = lateralAcceleration;
    }

    public String getLongitudinalAcceleration() {
        return longitudinalAcceleration;
    }

    public void setLongitudinalAcceleration(String longitudinalAcceleration) {
        this.longitudinalAcceleration = longitudinalAcceleration;
    }
}
