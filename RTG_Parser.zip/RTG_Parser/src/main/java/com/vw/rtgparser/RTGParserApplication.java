package com.vw.rtgparser;

import com.vw.rtgparser.Parser.RTGParser;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class RTGParserApplication {


	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(RTGParserApplication.class, args);

		// do something
		int exitCode = SpringApplication.exit(context, new ExitCodeGenerator() {
			@Override
			public int getExitCode() {
				return 0;
			}
		});

		System.exit(exitCode);
	}

	@Bean(initMethod="runAfterObjectCreated")
	public RTGParser getParserBean() {
		return new RTGParser();
	}

}
