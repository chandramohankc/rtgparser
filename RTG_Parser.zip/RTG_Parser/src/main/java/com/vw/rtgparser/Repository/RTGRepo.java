package com.vw.rtgparser.Repository;

import com.vw.rtgparser.model.RTG;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RTGRepo extends JpaRepository<RTG, String>
{

}